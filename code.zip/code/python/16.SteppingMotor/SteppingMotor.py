import RPi.GPIO as GPIO
import time

motorpins = (12,16,18,22)	#define pins connected to four phase ABCD of stepper motor
Reverse = (0x01,0x02,0x04,0x08)	#define power supply order for coil for rotating anticlockwise 
Forward = (0x08,0x04,0x02,0x01)	#define power supply order for coil for rotating clockwise

def setup():
	print("starting...")
	GPIO.setmode(GPIO.BOARD)
	for pin in motorpins:
		GPIO.setup(pin,GPIO.OUT)

def motorang(dir,ms):
	for j in range(0,4,1):
		for i in range(0,4,1):
			if (dir == 1):
				GPIO.output(motorpins[i],((Reverse[j] == 1<<i) and GPIO.HIGH or GPIO.LOW))
			else:
				GPIO.output(motorpins[i],((Forward[j] == 1<<i) and GPIO.HIGH or GPIO.LOW))
		if(ms<3):
			ms = 3
		time.sleep(ms*0.001)

def motordirang(dir,ms,steps):
	for i in range(steps):
		motorang(dir,ms)

def loop():
	while True:
		motordirang(1,3,512)
		time.sleep(0.5)
		motordirang(0,3,512)
		time.sleep(0.5)

def destroy():
	GPIO.cleanup()

if __name__ == '__main__':     # Program start from here
    setup()
    try:
        loop()
    except KeyboardInterrupt:  # When 'Ctrl+C' is pressed, the child program destroy() will be  executed.
        destroy()
