#include <wiringPi.h>
#include <pcf8591.h>
#include <stdio.h>
#include <softPwm.h>

#define address 0x48        
#define pinbase 64          
#define A0 pinbase + 0
#define A1 pinbase + 1
#define A2 pinbase + 2
#define A3 pinbase + 3

#define Z_Pin 1     

int main(void){
    int val_X,val_Y,val_Z;
    if(wiringPiSetup() == -1){ 
        printf("setup wiringPi failed !");
        return 1; 
    }
    pinMode(Z_Pin,INPUT);       
    pullUpDnControl(Z_Pin,PUD_UP);
    pcf8591Setup(pinbase,address);      
    
    while(1){
        val_Z = digitalRead(Z_Pin);  
        val_Y = analogRead(A0);      
        val_X = analogRead(A1);
        printf("val_X: %d  ,\tval_Y: %d  ,\tval_Z: %d \n",val_X,val_Y,val_Z);
        delay(100);
    }
    return 0;
}

